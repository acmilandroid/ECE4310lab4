//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by interface.rc
//
#define ID_FILE_LOADI                   40028
#define ID_FILE_LOAD                    40028
#define ID_FILE_QUIT                    40031
#define ID_DISPLAY_SHOWPIXELCOORDINATES 40042
#define ID_SHOWPIXELCOORDS              40042
#define ID_DISPLAY_CLIPIMAGECOORDINATES 40043
#define ID_DISPLAY_PLOTSIGNAL           40047
#define ID_LABEL_HELP                   40066

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
